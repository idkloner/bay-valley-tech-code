let colorToPaint = "white";

function attachColor(color){
    // assumes color is a string representing a CSS color.
    colorToPaint = color;
    console.log(colorToPaint);
}

function onClickMethod(e){
    // console.log(`${e.target.}`)
    console.log(`onclick: ${colorToPaint}`);
    e.target.style.background = colorToPaint;
}

function setOnClickOnAllElements(){
    const elementList = document.querySelectorAll('p');
    for (let element of elementList){
        element.addEventListener('click', onClickMethod);
    }
}


function makeGrid(numRows, numCols){
    const gameGrid = document.querySelector('#game');
    for (let i = 0; i < numRows ; i++){
        gameGrid.appendChild(makeRow(numCols));
    }
    console.log('made grid')
}

function makeRow(numCols){
    const row = document.createElement('div');
    row.classList.add('row');
    for (let i = 0; i < numCols; i++){
        row.appendChild(makeColumnElement());
    }
    return row;
}



function makeColumnElement(){
    const p = document.createElement('p');
    const col = document.createElement('div');
    col.classList.add('col');
    col.appendChild(p);
    return col;
}



window.addEventListener("load",() => {
    makeGrid(15,15);
    setOnClickOnAllElements();
});
